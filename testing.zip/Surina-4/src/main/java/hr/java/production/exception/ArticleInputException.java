package hr.java.production.exception;

public class ArticleInputException extends Exception{

    public ArticleInputException(String message){
        super(message);
    }

    public ArticleInputException(Throwable cause){
        super(cause);
    }

    public ArticleInputException(String message,Throwable cause){
        super(message,cause);
    }

}
