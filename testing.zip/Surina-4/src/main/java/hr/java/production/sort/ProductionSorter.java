package hr.java.production.sort;

import hr.java.production.model.Category;
import hr.java.production.model.Item;

import java.util.Comparator;
import java.util.Map;

public class ProductionSorter implements Comparator<Map.Entry<Category,Item>> {

    @Override
    public int compare(Map.Entry<Category,Item> first, Map.Entry<Category,Item> second) {
        if(first.getValue().getSellingPrice().doubleValue() > second.getValue().getSellingPrice().doubleValue()) {
            return 1;
        }
        else if (first.getValue().getSellingPrice().doubleValue() < second.getValue().getSellingPrice().doubleValue()) {
            return -1;
        }
        else {
            return 0;
        }
    }




}
