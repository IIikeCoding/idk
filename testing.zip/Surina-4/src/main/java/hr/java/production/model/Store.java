package hr.java.production.model;

import hr.java.production.main.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.*;

public class Store extends NamedEntity{

    public static final Logger logger = LoggerFactory.getLogger(Store.class);

    private String webAddress;
    //private Item[] items;
    Set<Item> listOfItems;

    //Constructors

    /**
     * Store class constructor
     * @param name is name of store
     */

    public Store(String name, String webAddress){

        setName(name);
        setWebAddress(webAddress);

        this.listOfItems = new TreeSet<>();

        logger.info("Created store class ", Store.class.getSimpleName());

    }

/*
    public Store(String name, String webAddress,Item[] items){

        setName(name);
        setWebAddress(webAddress);
        setItems(items);

    }*/

    //Setters

    public void setWebAddress(String webAddress){

        this.webAddress = webAddress;
    }
/*
    public void setItems(Item[] items){

        this.items = new Item[items.length];
        this.items = items.clone();
    }*/

    public void addItemToList(Item item){

        this.listOfItems.add(item);
    }


    //Getters

    public String getWebAddress(){

        return this.webAddress;
    }

    public List<Item> getItem(){

        return new ArrayList<>(listOfItems);
    }

    public Item getItemFromList(int index){

        return new ArrayList<>(listOfItems).get(index);
    }

    //equals() and hashcod()


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Store store = (Store) o;
        return Objects.equals(webAddress, store.webAddress) && Objects.equals(listOfItems, store.listOfItems);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), webAddress, listOfItems);
    }
}
