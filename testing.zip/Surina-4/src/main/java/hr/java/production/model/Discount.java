package hr.java.production.model;

public record Discount(double discountAmount) {

   /**
    * Discount record
    *
    */

   public double getDiscountAmount(){

      return this.discountAmount;
   }

}
