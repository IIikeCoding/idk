package hr.java.production.main;

import hr.java.production.exception.ArticleInputException;
import hr.java.production.exception.CategoryInputException;
import hr.java.production.model.*;
import hr.java.production.sort.ProductionSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.math.BigDecimal;
import java.util.*;


public class Main {

    static final int CATEGORY_ARRAY_SIZE = 3;
    static final int ITEM_ARRAY_SIZE = 5;
    static final int FACTORY_ARRAY_SIZE = 2;
    static final int STORE_ARRAY_SIZE = 2;

    public static final Logger logger = LoggerFactory.getLogger(Main.class);


    /**
     * Main method
     * @param args console line arguments
     */


    public static void main(String[] args){

        Scanner scan = new Scanner(System.in);

        logger.info("starting program ");

        List<Category> categories = new ArrayList<>();
        List<Item> itemsList = new ArrayList<>();
        List<Factory> factories = new ArrayList<>();
        List<Store> stores = new ArrayList<>();

        //Unos kategorija
        System.out.println("Enter info for categories ");


        for(int i = 0;i < CATEGORY_ARRAY_SIZE;i++){
            int tmpI = i + 1;
            System.out.println("Name of " + tmpI + ". category: ");

            String name;
            boolean notGoodName = true;
            boolean hasDuplicate;

            if(i > 0) {
                do {
                    hasDuplicate = false;
                    name = scan.nextLine();

                    for (int j = 0; j < i; j++) {
                        if (name.equals(categories.get(j).getName())) {
                            hasDuplicate = true;
                            break;
                        }
                    }

                    if (hasDuplicate) {
                        try {
                            throw new CategoryInputException("Duplicate name.Please choose another name");
                        } catch (CategoryInputException e) {
                            logger.info(e.getMessage(), e);
                            System.out.println(e.getMessage());
                        }

                    } else {
                        notGoodName = false;
                    }

                } while (notGoodName);

            }else{
                name = scan.nextLine();
            }

            System.out.println("Description of " + tmpI + ". category: ");
            String description = scan.nextLine();
            Category tempCategory = new Category(name,description);
            categories.add(tempCategory);
        }



        //Unos za klasu item i odabir vrste hrane
        System.out.println("Enter info for five items");

        //Varijable za provjeru podataka
        int biggestCalorieFood = 0;
        int biggestCalorieIndex = 0;

        double biggestWeightPerPrice = 0.0;
        int biggestPriceIndex = 0;

        boolean hasFood = false;

        //Laptop[] arrOfLaptops = new Laptop[ITEM_ARRAY_SIZE];
        List<Laptop> arrOfLaptops = new ArrayList<>();
        int laptopCounter = 0;
        boolean hasLaptop = false;


        boolean repeatInput;

        //for loop starts here
        for(int i = 0; i < ITEM_ARRAY_SIZE; i++) {

            int tmpI = i + 1;

            System.out.println("Do you want an articale for food,laptop or something else " +
                    "(Write hrana for food,laptop for laptop and for everything else write ostalo )");


            String typeOfArticle = scan.nextLine();
            typeOfArticle = typeOfArticle.toLowerCase(Locale.ROOT).trim();

            if (typeOfArticle.equals("ostalo")) {

                System.out.println("You have chosen miscellaneous");


                    System.out.println("Name of  " + tmpI + ". item: ");
                    String name = scan.nextLine();

                    System.out.println("Name of " + tmpI + ". item category: ");
                    String categoryName = scan.nextLine();

                    System.out.println("Description of  " + tmpI + ". category : ");
                    String categoryDescription = scan.nextLine();

                    System.out.println("Width of the " + tmpI + ". item: ");
                    double width = doubleException();

                    System.out.println("Height of the " + tmpI + ". item: ");
                    double height = doubleException();

                    System.out.println("Lenght of the " + tmpI + ". item: ");
                    double length = doubleException();

                    System.out.println("Manufacturing price of the  " + tmpI + ". item: ");
                    double productionCost = doubleException();

                    System.out.println("Price of " + tmpI + ". item: ");
                    double sellingPrice = doubleException();

                    System.out.println("Discount " + tmpI + ". in percentages");

                    double discount = doubleException();

                    //Consume nextLine \n
                    scan.nextLine();

                    Item tempItem = new Item(name, categoryName, categoryDescription, width,
                            height, length, productionCost, sellingPrice-(sellingPrice*(discount*0.01)));

                    tempItem.setDiscount(discount);

                    itemsList.add(tempItem);

            }else if(typeOfArticle.equals("hrana")) {

                //Unos hrane

                System.out.println("You have chosen food");
                System.out.println("We are offering: Burek s Mesom and Sarma.\nwrite sarma for sarma or burek for burek s mesom");

                String typeOfFood = scan.nextLine();
                typeOfFood = typeOfFood.trim().toLowerCase(Locale.ROOT);

                if (typeOfFood.equals("sarma")){
                    //Sarma

                    System.out.println("You have chosen sarma ");


                    System.out.println("Name of the  " + tmpI + ". item: ");
                    String name = scan.nextLine();

                    System.out.println("Name of the " + tmpI + ". item category: ");
                    String categoryName = scan.nextLine();

                    System.out.println("Description of " + tmpI + ". item category: ");
                    String categoryDescription = scan.nextLine();

                    System.out.println("Width of " + tmpI + ". item: ");
                    double width = doubleException();

                    System.out.println("Height of " + tmpI + ". item: ");
                    double height = doubleException();

                    System.out.println("Length of " + tmpI + ". item: ");
                    double length = doubleException();

                    System.out.println("Manufacturing price of " + tmpI + ". item: ");
                    double productionCost = doubleException();

                    System.out.println("PRice of " + tmpI + ". item: ");
                    double sellingPrice = doubleException();

                    System.out.println("Discount " + tmpI + ". in percentages");

                    double discount = doubleException();

                    Sarma sarma = new Sarma(name,categoryName,categoryDescription,
                            width,height,length,productionCost,sellingPrice-(sellingPrice*(discount*0.01)));

                    sarma.setDiscount(discount);

                    System.out.println("How much kilograms do you want:");
                    sarma.setWeight(doubleException());

                    System.out.println("Sarma with that much Kgs has " + sarma.calculateKilocalories() + " calories");
                    System.out.println("Sarma with that much Kgs has " + sarma.calculatePrice() + " price");

                    if(sarma.calculateKilocalories() >= biggestCalorieFood){

                        biggestCalorieFood = sarma.calculateKilocalories();
                        biggestCalorieIndex = i;

                    }

                    if(sarma.calculatePrice() >= biggestWeightPerPrice){

                        biggestWeightPerPrice = sarma.calculatePrice();
                        biggestPriceIndex = i;

                    }

                    //Consume nextLine \n
                    scan.nextLine();


                    itemsList.add(sarma);
                    hasFood = true;

                }else if(typeOfFood.equals("burek")){
                    //Burek

                    System.out.println("You have chosen burek ");

                    System.out.println("Name of " + tmpI + ". item: ");
                    String name = scan.nextLine();

                    System.out.println("Name of " + tmpI + ". item category: ");
                    String categoryName = scan.nextLine();

                    System.out.println("Description of " + tmpI + ". category: ");
                    String categoryDescription = scan.nextLine();

                    System.out.println("Width of  " + tmpI + ". item: ");
                    double width = doubleException();

                    System.out.println("Height of  " + tmpI + ". item: ");
                    double height = doubleException();

                    System.out.println("Length of  " + tmpI + ". item: ");
                    double length = doubleException();

                    System.out.println("Manufacturing price of  " + tmpI + ". item: ");
                    double productionCost = doubleException();

                    System.out.println("Price of  " + tmpI + ". item: ");
                    double sellingPrice = doubleException();

                    System.out.println("Discount of " + tmpI + ". in percentages");

                    double discount = doubleException();

                    BurekZMesom burekZMesom = new BurekZMesom(name,categoryName,categoryDescription,
                            width,height,length,productionCost,sellingPrice-(sellingPrice*(discount*0.01)));

                    burekZMesom.setDiscount(discount);

                    System.out.println("How much kilograms do you want:");

                    burekZMesom.setWeight(doubleException());

                    System.out.println("Burek with that much kgs has " + burekZMesom.calculateKilocalories() + " calories");
                    System.out.println("Burek with that much kgs has " + burekZMesom.calculatePrice() + " price");

                    if(burekZMesom.calculateKilocalories() >= biggestCalorieFood){

                        biggestCalorieFood = burekZMesom.calculateKilocalories();
                        biggestCalorieIndex = i;

                    }

                    if(burekZMesom.calculatePrice() >= biggestWeightPerPrice){

                        biggestWeightPerPrice = burekZMesom.calculatePrice();
                        biggestPriceIndex = i;

                    }

                    //Consume nextLine \n
                    scan.nextLine();

                    itemsList.add(burekZMesom);
                    hasFood = true;

                }else{

                    System.out.println("Poor choice of words.Type again");
                    logger.info("Wrong type of food");
                    i -= 1;
                }


            }else if(typeOfArticle.equals("laptop")){

                System.out.println("You have chosen laptop");

                System.out.println("Name of " + tmpI + ". item: ");
                String name = scan.nextLine();

                System.out.println("Name of " + tmpI + ". item category: ");
                String categoryName = scan.nextLine();

                System.out.println("Description of " + tmpI + ". category : ");
                String categoryDescription = scan.nextLine();

                System.out.println("Width of " + tmpI + ". item: ");
                double width = doubleException();

                System.out.println("Height of " + tmpI + ". item: ");
                double height = doubleException();

                System.out.println("Length of " + tmpI + ". item: ");
                double length = doubleException();

                System.out.println("Manufacturing price of " + tmpI + ". item: ");
                double productionCost = doubleException();

                System.out.println("PRice of " + tmpI + ". item: ");
                double sellingPrice = doubleException();

                System.out.println("Discount of " + tmpI + ". item in percentages");

                double discount = doubleException();


                Laptop laptop = new Laptop(name,categoryName,categoryDescription,
                        width,height,length,productionCost,sellingPrice-(sellingPrice*(discount*0.01)));

                laptop.setDiscount(discount);

                System.out.println("Please enter warranty info ");

                //REFACTOR
                int warrantTime = 0;
                do{
                    repeatInput = false;
                    try{
                        warrantTime = integerException();
                    }catch (InputMismatchException e){
                        scan.nextLine();
                        repeatInput = true;
                        logger.info(e.getMessage(), e);
                        System.out.println("Please enter integer type number");
                    }
                }while(repeatInput);


                laptop.setWarrantTime(warrantTime);

                itemsList.add(laptop);

                arrOfLaptops.add(new Laptop(laptop));

                laptopCounter += 1;

                hasLaptop = true;

                //Consume nextLine \n
                scan.nextLine();


            }else{

                System.out.println("Wrong choice.Type again.");
                i -= 1;

                logger.info("Wrong article selection", Main.class.getSimpleName());

            }
            //if statement ends here

        }
        //FOR LOOP ENDS HERE

        //Printanje najvise kilokalorija i najveca cijena
        if(hasFood){

            System.out.println("Food with most kilocalories is " + itemsList.get(biggestCalorieIndex).getName() + " with " + biggestCalorieFood + " calories");
            System.out.println("Food with the biggest price is " + itemsList.get(biggestPriceIndex).getName() + " with price of " + biggestWeightPerPrice + " hrk");
        }

        //Najkraci garantni rok

        if(hasLaptop){

            int smallestWarrantTime = arrOfLaptops.get(0).getWarrantTime();
            int index = 0;
            for(int i = 0;i < laptopCounter;i++){

                if(arrOfLaptops.get(i).getWarrantTime() <= smallestWarrantTime){
                    smallestWarrantTime = arrOfLaptops.get(i).getWarrantTime();
                    index = i;

                }

            }

            System.out.println("Laptop with the lowest warranty is " + arrOfLaptops.get(index).getName() + " with "
                    + arrOfLaptops.get(index).getWarrantTime() + " months");

        }

        //Odabir za tvornice
        System.out.println("Please enter info for two factories: ");

        for(int i = 0;i < FACTORY_ARRAY_SIZE;i++){

            int tmpI = i + 1;

            System.out.println("Name of " + tmpI + ". factory: ");
            String name = scan.nextLine();

            System.out.println("Address of " + tmpI + ". factory: ");
            String streetName = scan.nextLine();

            System.out.println("Address number of " + tmpI + ". factory: ");
            String houseNumber = scan.nextLine();

            System.out.println("City of " + tmpI + ". factory: ");
            String city = scan.nextLine();

            System.out.println("Postal code " + tmpI + ". factory: ");
            String postalCode = scan.nextLine();


            //Address builder pattern
            Address tmpAddress = new Address.Builder()
                    .onStreet(streetName)
                    .withHouseNumber(houseNumber)
                    .inCity(city)
                    .withPostalCode(postalCode)
                    .build();

            Factory tempFactory = new Factory(name, tmpAddress);
            factories.add(tempFactory);

            int multipleSelectionNumber = 5;
            //for loop for article selection
            for(int j = 0;j < itemsList.size();j++){

                System.out.println("Please choose the article for your factory");
                int selectedItem;

                boolean rightNumber = false;

                //ispis ponudenih artikla
                for(int k = 0;k < itemsList.size();k++){
                    int tmpK = k+1;
                    System.out.println(tmpK + ". article is " + itemsList.get(k).getName() +
                            " -- write " + k + " number for selection");
                }

                do{

                    selectedItem = integerException();

                     if(checkNumber(selectedItem)){

                         System.out.println("You have chosen " + itemsList.get(selectedItem).getName());

                        if(multipleSelectionNumber == selectedItem){
                            try {

                                throw new ArticleInputException("You have chosen the same article twice in a row\n" +
                                        "Please enter new number");

                            }catch (ArticleInputException e){
                                logger.info(e.getMessage(), e);
                                System.out.println(e.getMessage());
                            }
                        }else{
                            multipleSelectionNumber = selectedItem;
                            rightNumber = true;
                            factories.get(i).addItemToList(itemsList.get(selectedItem));
                        }

                     }else{
                         System.out.println("Wrong number please type again");
                         logger.info("Wrong number when selecting articles", Main.class.getSimpleName());
                     }

                }while(!rightNumber);

            }
        }

        //Odabir za trgovine
        System.out.println("Please enter info for two stores: ");

        for(int i = 0;i < STORE_ARRAY_SIZE;i++){

            int tmpI = i + 1;

            System.out.println("Name of " + tmpI + ". Store: ");
            String name = scan.nextLine();

            System.out.println("Address name of " + tmpI + ". Store: ");
            String webAddress = scan.nextLine();

            Store tempStore = new Store(name,webAddress);
            stores.add(tempStore);
            int multipleSelectionNumber = 5;
            //for loop for article selection
            for(int j = 0;j < itemsList.size();j++){

                System.out.println("Please chose the article you want in the store");
                int selectedItem;

                boolean rightNumber = false;

                //ispis ponudenih artikla
                for(int k = 0;k < itemsList.size();k++){
                    int tmpK = k+1;
                    System.out.println(tmpK + ". article is" + itemsList.get(k).getName() +
                            " -- write " + k + " number of selection");
                }

                do{

                    selectedItem = integerException();

                    if(checkNumber(selectedItem)){

                        System.out.println("You have chosen " + itemsList.get(selectedItem).getName());

                        if(multipleSelectionNumber == selectedItem){
                            try {

                                throw new ArticleInputException("You have chosen the same article twice in a row\n" +
                                        "Please enter new number");

                            }catch (ArticleInputException e){
                                logger.info(e.getMessage(), e);
                                System.out.println(e.getMessage());
                            }
                        }else{
                            multipleSelectionNumber = selectedItem;
                            rightNumber = true;
                            stores.get(i).addItemToList(itemsList.get(selectedItem));
                        }

                    }else{
                        System.out.println("Wrong number,please choose again.");
                        logger.info("Wrong number was chosen");
                    }

                }while(!rightNumber);

            }


        }

        //Tvornice sa najvecim volumenom
        int biggestVolumeIndex = 0;
        int FactoryIndex = 0;
        Double biggestVolume = 0.0;

        for(int i = 0;i < FACTORY_ARRAY_SIZE;i++){
            for(int j = 0;j < factories.get(i).getItem().size();j++){

                if(biggestVolume < factories.get(i).getSpecificItem(j).getVolume()){

                    biggestVolume = factories.get(i).getSpecificItem(j).getVolume();
                    FactoryIndex = i;
                    biggestVolumeIndex = j;
                }
            }
        }

        System.out.println("Factory with the biggest product is " +  factories.get(FactoryIndex).getName());

        System.out.println("Biggest product is " +  factories.get(FactoryIndex).getSpecificItem(biggestVolumeIndex).getName());


        //Najeftiniji artikl u Ducanima

        int storeIndex = 0, itemindex = 0;
        BigDecimal cheapestItemTmp = stores.get(0).getItem().get(0).getSellingPrice();
        double cheapestItem = cheapestItemTmp.doubleValue();

        for(int i = 0;i < stores.size();i++){
            for(int j = 0;j < stores.get(i).getItem().size();j++){

                if(cheapestItem > stores.get(i).getItem().get(j).getSellingPrice().doubleValue()){

                    storeIndex = i;
                    itemindex = j;

                    cheapestItem = stores.get(i).getItem().get(j).getSellingPrice().doubleValue();

                }
            }
        }

        System.out.println("The store with the cheapest product is " +  stores.get(storeIndex).getName());

        System.out.println("Cheapest product in that store is " +  stores.get(storeIndex).getItem().get(itemindex).getName());


        //7 zadatak 4.labos -> nisam znao kako da ovo uklopim u prosle pripreme zato jer mapa key treba bit jedinstven
        //a sto ako imamo dva ili vise itema sa istom kategorijom tipa moze biti vise vrsta hrane

        Map<Category, Item> mapOfItems = new HashMap<>();
        List<Item> edibleAndTechItems = new ArrayList<>();

        for(Item e : itemsList){

            String name,description;

            System.out.println("Please enter name for next category");
            name = scan.nextLine();
            System.out.println("Please enter description for next category");
            description = scan.nextLine();

            mapOfItems.put(new Category(name,description),e);

            if(e instanceof Sarma || e instanceof BurekZMesom || e instanceof Laptop){
                edibleAndTechItems.add(e);
            }

        }

        List<Map.Entry<Category,Item>> listOfValuesOfItems = new LinkedList<Map.Entry<Category,Item>>(mapOfItems.entrySet());

        Collections.sort(listOfValuesOfItems,new ProductionSorter());

        HashMap<Category, Item> newMapOfItem = new LinkedHashMap<Category, Item>();
        for(Map.Entry<Category, Item> aa : listOfValuesOfItems){
            newMapOfItem.put(aa.getKey(), aa.getValue());
        }

        Collections.sort(edibleAndTechItems, new Comparator<Item>() {
            @Override
            public int compare(Item first, Item second) {
                return Double.compare(first.getSellingPrice().doubleValue(), second.getSellingPrice().doubleValue());
            }
        });

        System.out.println("Cheapast item: "+edibleAndTechItems.get(0));
        System.out.println("Most expensive item: "+edibleAndTechItems.get(edibleAndTechItems.size()-1));


    }





    public static double doubleException(){

        Scanner scan = new Scanner(System.in);
        double number = 0.0;
        boolean repeatInput;

        do{
            repeatInput = false;
            try{

                number = scan.nextDouble();

            }catch (InputMismatchException e){
                scan.nextLine();
                repeatInput = true;
                logger.info(e.getMessage(), e);
                System.out.println("Please enter a number of type boolean");
            }
        }while(repeatInput);

        return number;
    }

    public static int integerException(){

        Scanner scan = new Scanner(System.in);
        int number = 0;
        boolean repeatInput;

        do{
            repeatInput = false;
            try{

                number = scan.nextInt();

            }catch (InputMismatchException e){
                scan.nextLine();
                repeatInput = true;
                logger.info(e.getMessage(), e);
                System.out.println("Please enter a number of type integer");
            }
        }while(repeatInput);

        return number;
    }

    public static boolean checkNumber(int number){

        return number >= 0 && number < ITEM_ARRAY_SIZE;

    }


}
