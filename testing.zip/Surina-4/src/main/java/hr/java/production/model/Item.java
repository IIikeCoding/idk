package hr.java.production.model;

import hr.java.production.main.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Objects;

public class Item extends NamedEntity{

    public static final Logger logger = LoggerFactory.getLogger(Item.class);

    private Category category;
    protected BigDecimal width,height,length,productionCost,sellingPrice;
    protected Discount discount;

    //Constructors

    public Item(){}

    /**
     * Item class constructor
     * @param name is name of class
     */

    public Item(String name,String CategoryName,String CategoryDescription,double width,double height,double length,double productionCost,double sellingPrice){

        setName(name);
        setCategory(CategoryName,CategoryDescription);
        setBigDecimal( width, height, length, productionCost, sellingPrice);

        logger.info("Created item class ", Item.class.getSimpleName());

    }

    //Setters

    public void setBigDecimal(double width,double height,double length,double productionCost,double sellingPrice){

        this.width = new BigDecimal(Double.toString(width));
        this.height = new BigDecimal(Double.toString(height));
        this.length = new BigDecimal(Double.toString(length));
        this.productionCost = new BigDecimal(Double.toString(productionCost));
        this.sellingPrice = new BigDecimal(Double.toString(sellingPrice));

    }


    public void setCategory(String CategoryName,String CategoryDescription){

        this.category = new Category(CategoryName,CategoryDescription);
    }

    public void setNewCategory(Category category){
        this.category = new Category(category.getName(), category.getDescription());
    }

    public void setDiscount(double discount){

        this.discount = new Discount(discount);

    }

    //Getters


    public Category getCategory(){

        return this.category;
    }

    public BigDecimal getHeight(){

        return this.height;
    }

    public BigDecimal getWidth(){

        return this.width;
    }

    public BigDecimal getLength(){

        return this.length;
    }

    public BigDecimal getProductionCost(){

        return this.productionCost;
    }

    public BigDecimal getSellingPrice(){

        return this.sellingPrice;
    }

    public Double getVolume(){

        Double volume = this.height.doubleValue() * this.width.doubleValue() * this.length.doubleValue();

        return volume;
    }

    public double getDiscount(){

        return this.discount.getDiscountAmount();
    }

    //equals() and hashcode()


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Item item = (Item) o;
        return Objects.equals(category, item.category) && Objects.equals(width, item.width) && Objects.equals(height, item.height) && Objects.equals(length, item.length) && Objects.equals(productionCost, item.productionCost) && Objects.equals(sellingPrice, item.sellingPrice) && Objects.equals(discount, item.discount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(category, width, height, length, productionCost, sellingPrice, discount);
    }

}
