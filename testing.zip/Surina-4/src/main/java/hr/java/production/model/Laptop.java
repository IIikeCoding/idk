package hr.java.production.model;

import hr.java.production.main.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

public final class Laptop extends Item implements Technical{

    private int warrantTime;

    public static final Logger logger = LoggerFactory.getLogger(Laptop.class);

    //Constructors

    /**
     * Laptop class constructor
     * @param
     */

    public Laptop(){};


    /**
     * Laptop class constructor
     * @param name is name of laptop
     */

    public Laptop (String name,String CategoryName,String CategoryDescription,double width,double height,double length,
                   double productionCost,double sellingPrice){
        super(name,CategoryName,CategoryDescription,width,height,length,productionCost,sellingPrice);

        logger.info("Created laptop class ", Laptop.class.getSimpleName());

    }

    public Laptop (Laptop that){

        super(that.getName(),that.getCategory().getName(),that.getCategory().getDescription(),
                that.getWidth().doubleValue(),that.getHeight().doubleValue(),that.getLength().doubleValue(),
                that.getProductionCost().doubleValue(),that.getSellingPrice().doubleValue());

        this.warrantTime = that.warrantTime;

        logger.info("Created laptop copy constructor  ", Laptop.class.getSimpleName());

    }

    //Setters

    public void setWarrantTime(int warrantTime){

        this.warrantTime = warrantTime;

    }


    //Getters
    @Override
    public int getWarrantTime() {
        return this.warrantTime;
    }


    //equals() and hashcod()


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Laptop laptop = (Laptop) o;
        return warrantTime == laptop.warrantTime;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), warrantTime);
    }
}
