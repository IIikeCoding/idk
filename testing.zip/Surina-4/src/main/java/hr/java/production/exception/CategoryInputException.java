package hr.java.production.exception;

public class CategoryInputException extends RuntimeException{

    public CategoryInputException(String message){
        super(message);
    }

    public CategoryInputException(Throwable cause){
        super(cause);
    }

    public CategoryInputException(String message, Throwable cause){
        super(message, cause);
    }
}
