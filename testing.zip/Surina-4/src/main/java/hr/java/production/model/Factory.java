package hr.java.production.model;

import hr.java.production.main.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public  class Factory extends NamedEntity{

    public static final Logger logger = LoggerFactory.getLogger(Factory.class);

    private Address address;
    //List<Item> listOfItems;
    Set<Item> listOfItems;

    //Constructors

    /**
     * Factory class constructor
     * @param name is name of class
     */

    public Factory(String name,Address address){
        setName(name);
        setAddress(address);
        this.listOfItems = new TreeSet<>();

        logger.info("Created factory class ", Factory.class.getSimpleName());

    }


    //Setters



    public void setAddress(Address address){

        //this.address = new Address(address.getStreet(), address.getHouseNumber(), address.getCity(), address.getPostalCode() );

        this.address = new Address.Builder()
                .onStreet(address.getStreet())
                .withHouseNumber(address.getHouseNumber())
                .inCity(address.getCity())
                .withPostalCode(address.getPostalCode())
                .build();

    }

    public void addItemToList(Item item){

        this.listOfItems.add(item);
    }

    //Getters



    public Address getAddress(){

        return this.address;
    }

    public List<Item> getItem(){

        return new ArrayList<>(listOfItems);
    }

    public Item getSpecificItem(int index){

        return new ArrayList<>(listOfItems).get(index);
    }

    //equals() and hashcode()


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Factory factory = (Factory) o;
        return Objects.equals(address, factory.address) && Objects.equals(listOfItems, factory.listOfItems);
    }

    @Override
    public int hashCode() {
        return Objects.hash(address, listOfItems);
    }
}
