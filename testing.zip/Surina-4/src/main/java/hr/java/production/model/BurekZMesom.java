package hr.java.production.model;

import hr.java.production.main.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Objects;

public class BurekZMesom extends Item implements Edible{

    public static final Logger logger = LoggerFactory.getLogger(BurekZMesom.class);

    private static final int NUMBER_OF_CALORIES_PER_KILO = 260;

    private BigDecimal weight;

    /**
     * BurekZMesom class constructor
     * @param
     */

    public BurekZMesom(String name,String CategoryName,String CategoryDescription,double width,double height,double length,double productionCost,double sellingPrice){
        super(name,CategoryName,CategoryDescription,width,height,length,productionCost,sellingPrice);
        logger.info("Created burek class ", BurekZMesom.class.getSimpleName());
    }

    public int calculateKilocalories(){

        return this.weight.intValue() * BurekZMesom.NUMBER_OF_CALORIES_PER_KILO;
    }
    public double calculatePrice(){

        return this.weight.doubleValue() * super.sellingPrice.doubleValue();
    }
    //Setters

    public void setWeight(double weight){

        this.weight = new BigDecimal(weight);
    }

    //Getters

    public BigDecimal getWeight(){

        return this.weight;
    }

    public int getNUMBER_OF_CALORIES_PER_KILO(){

        return  BurekZMesom.NUMBER_OF_CALORIES_PER_KILO;
    }

    //equals() and hashcode()

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BurekZMesom that = (BurekZMesom) o;
        return Objects.equals(weight, that.weight);
    }

    @Override
    public int hashCode() {
        return Objects.hash(weight);
    }
}
