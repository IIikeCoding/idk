package hr.java.production.model;

public interface Edible {

    int calculateKilocalories();
    double calculatePrice();
}
