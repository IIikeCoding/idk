package hr.java.production.model;

import hr.java.production.main.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

public class Category extends NamedEntity{

    public static final Logger logger = LoggerFactory.getLogger(Category.class);

    private String description;

    //Constructors

    /**
     * Category class constructor
     * @param name Is name
     */

    public Category(String name,String description){

        setName(name);
        setDescription(description);

        logger.info("Created category class ", Category.class.getSimpleName());

    }

    //Setters


    public void setDescription(String description){

        this.description = description;

    }

    //Getters



    public String getDescription(){

        return this.description;
    }

    //equals() and hashcode()


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Category category = (Category) o;
        return Objects.equals(description, category.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(description);
    }
}
