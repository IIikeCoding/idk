package hr.java.production.enumeration;

public enum CityEnumeration {

    City_1("NAME","POSTAL_CODE"),City_2("NAME","POSTAL_CODE"),
    City_3("NAME","POSTAL_CODE"),City_4("NAME","POSTAL_CODE");

    private String name;
    private String postalCode;

    CityEnumeration(){}

    CityEnumeration(String name, String postalCode){
        this.name = name;
        this.postalCode = postalCode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getName() {
        return this.name;
    }

    public String getPostalCode() {
        return this.postalCode;
    }
}
