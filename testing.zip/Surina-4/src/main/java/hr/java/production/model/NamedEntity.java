package hr.java.production.model;


import java.util.Objects;

public class NamedEntity{

    private String name;

    public NamedEntity(){

    };

    //Setters
    public void setName(String name){

        this.name = name;
    }

    //Getters

    public String getName(){

        return this.name;
    }

    //equals() and hashcod()


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NamedEntity that = (NamedEntity) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

}
