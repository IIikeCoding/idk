package hr.java.production.model;

import hr.java.production.enumeration.CityEnumeration;
import hr.java.production.main.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

/**
 * Address class
 */

public class Address {

    public static final Logger logger = LoggerFactory.getLogger(Main.class);

    private String street,houseNumber;

    private CityEnumeration cityEnum;

    public static class Builder{

        private String street,houseNumber;

        private CityEnumeration cityEnum;

        public Builder(){}

        public Builder onStreet(String street){

            this.street = street;

            return this;
        }

        public Builder withHouseNumber(String houseNumber){

            this.houseNumber = houseNumber;

            return this;
        }

        public Builder inCity(String city){

            this.cityEnum.setName(city);

            return this;
        }

        public Builder withPostalCode(String postalCode){

            this.cityEnum.setPostalCode(postalCode);

            return this;
        }

        /**
         * Address build method that finishes builder method
         */

        public Address build(){

            logger.info("Created address class ", Address.class.getSimpleName());

            Address address = new Address();
            address.street = this.street;
            address.houseNumber = this.houseNumber;
            address.cityEnum.setName(this.cityEnum.getName());
            address.cityEnum.setPostalCode(this.cityEnum.getPostalCode());


            return address;
        }


    }

    //Constructors



    /**
     * Address constructor
     */

    public Address(){

    }

    public Address(String street,String houseNumber,String city,String postalCode){

        setStreet(street);
        setCity(houseNumber);
        setHouseNumber(city);
        setPostalCode(postalCode);

    }


    //Setters

    public void setStreet(String street){
        this.street = street;
    }

    public void setHouseNumber(String houseNumber){
        this.houseNumber = houseNumber;
    }

    public void setCity(String city){



        this.cityEnum.setName(city);
    }

    public void setPostalCode(String postalCode){


        this.cityEnum.setPostalCode(postalCode);
    }

    //Getters

    public String getStreet(){

        return this.street;
    }

    public String getHouseNumber(){

        return this.houseNumber;
    }

    public String getCity(){

        return this.cityEnum.getName();
    }

    public String getPostalCode(){

        return this.cityEnum.getPostalCode();
    }

    //equals() and hashcode()


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address address = (Address) o;
        return Objects.equals(street, address.street) && Objects.equals(houseNumber, address.houseNumber) && cityEnum == address.cityEnum;
    }

    @Override
    public int hashCode() {
        return Objects.hash(street, houseNumber, cityEnum);
    }
}
